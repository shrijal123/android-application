before executing project run following command in terminal
pip install ai

install reportlab
pip install reportlab

steps for converting main.py into exe file

Step 1:- In terminal type pip install pyinstaller 
Step 2:- type in terminal pyinstaller main.py --onefile 
Step 3:- check the Disc folder and install the exe file